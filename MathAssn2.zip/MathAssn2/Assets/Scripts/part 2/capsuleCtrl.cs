using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class capsuleCtrl : MonoBehaviour
{
        Capsule caps = new Capsule();
        public GameObject Ground;
        Square ground = new Square();

        Vector2 Integrate(Vector2 initial, Vector2 change, float t)
    {
        return initial + change * t;

    }
    // Update is called once per frame
    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;

        caps.position = transform.position;
        caps.mass = 30f;
        caps.acc = new Vector2(0, -9.8f) / caps.mass;
        caps.vel = Integrate(caps.vel, caps.acc, dt);
        caps.position = Integrate(caps.position, caps.vel, dt);
    }
    void Update()
    {
         ground.position = Ground.transform.position;
        ground.extents = new Vector3(Ground.transform.localScale.x * 0.5f, Ground.transform.localScale.y * 0.5f);

        if (Input.GetKey(KeyCode.T))
        {
            caps.vel = transform.up * 2;
             if (CheckGroundCollision(gameObject)) transform.position = caps.position;
        }
        else if (Input.GetKey(KeyCode.G))
        {
            caps.vel = transform.up * -2;
        }
        if(Input.GetKey(KeyCode.H))
        {
            caps.vel = transform.right * 2;

        }
         if(Input.GetKey(KeyCode.F))
        {
            caps.vel = transform.right * -2;

        }
         if (!CheckGroundCollision(gameObject))
        {
            transform.position = caps.position;
        }

    }
    public bool CheckGroundCollision(GameObject obj)
    {
        float objectBottom = obj.transform.position.y - 0.5f;
        float groundTop = ground.position.y + ground.extents.y;
        bool isAboveGround = objectBottom >= groundTop;
        return !isAboveGround;
    }
}
