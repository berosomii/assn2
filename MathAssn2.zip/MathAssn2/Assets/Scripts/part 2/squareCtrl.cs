using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class squareCtrl : MonoBehaviour

{
    Square squ = new Square();
    public GameObject Ground;
    Square ground = new Square();

  
    Vector2 Integrate(Vector2 initial, Vector2 change, float t)
    {
        return initial + change * t;
    }
    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;

        squ.position = transform.position;
        squ.mass = 10f;
        squ.acc = new Vector2(0, -9.8f) / squ.mass;
        squ.vel = Integrate(squ.vel, squ.acc, dt);
        squ.position = Integrate(squ.position, squ.vel, dt);

    }
    public void Update()
    {
        ground.position = Ground.transform.position;
        ground.extents = new Vector3(Ground.transform.localScale.x * 0.5f, Ground.transform.localScale.y * 0.5f);

        if (Input.GetKey(KeyCode.W))
        {
            squ.vel = transform.up * 2;
            if (CheckGroundCollision(gameObject)) transform.position = squ.position;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            squ.vel = transform.up * -2;
        }
        if (Input.GetKey(KeyCode.A))
        {
            squ.vel = transform.right * -2;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            squ.vel = transform.right * 2;
        }
        if (!CheckGroundCollision(gameObject))
        {
            transform.position = squ.position;
        }
    }
    public bool CheckGroundCollision(GameObject obj)
    {
        float objectBottom = obj.transform.position.y - 0.5f;
        float groundTop = ground.position.y + ground.extents.y;
        bool isAboveGround = objectBottom >= groundTop;
        return !isAboveGround;
    }
}