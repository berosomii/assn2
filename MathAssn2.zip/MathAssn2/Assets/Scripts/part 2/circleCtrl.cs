using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class circleCtrl : MonoBehaviour
{
        Circle cir = new Circle();
        public GameObject Ground;
        Square ground = new Square();

        Vector2 Integrate(Vector2 initial, Vector2 change, float t)
    {
        return initial + change * t;

    }
    // Update is called once per frame
    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;

        cir.position = transform.position;
        cir.mass = 15f;
        cir.acc = new Vector2(0, -9.8f) / cir.mass;
        cir.vel = Integrate(cir.vel, cir.acc, dt);
        cir.position = Integrate(cir.position, cir.vel, dt);
    }
    void Update()
    {
         ground.position = Ground.transform.position;
        ground.extents = new Vector3(Ground.transform.localScale.x * 0.5f, Ground.transform.localScale.y * 0.5f);

        if (Input.GetKey(KeyCode.I))
        {
            cir.vel = transform.up * 2;
             if (CheckGroundCollision(gameObject)) transform.position = cir.position;
        }
        else if (Input.GetKey(KeyCode.K))
        {
            cir.vel = transform.up * -2;
        }
        if(Input.GetKey(KeyCode.L))
        {
            cir.vel = transform.right * 2;

        }
         if(Input.GetKey(KeyCode.J))
        {
            cir.vel = transform.right * -2;

        }
         if (!CheckGroundCollision(gameObject))
        {
            transform.position = cir.position;
        }

    }
    public bool CheckGroundCollision(GameObject obj)
    {
        float objectBottom = obj.transform.position.y - 0.5f;
        float groundTop = ground.position.y + ground.extents.y;
        bool isAboveGround = objectBottom >= groundTop;
        return !isAboveGround;
    }
}
