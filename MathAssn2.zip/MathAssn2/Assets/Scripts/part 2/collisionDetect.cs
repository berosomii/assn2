using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

     public class Circle
{
    public Vector2 acc;
    public float mass;
    public Vector2 vel;
    public Vector2 position;
    public float radius;

}   
    public class Capsule
 {
    public Vector2 acc;
    public float mass;
    public Vector2 vel;
    public Vector2 position;
    public float radius;
    public Vector2 top;
    public Vector2 bot;
    public Vector2 direction;
    public float halfHeight;
    
 }
    public class Square
 {
     public Vector2 acc;
     public Vector2 extents;
    public float mass;
    public Vector2 vel;
    public Vector2 position;

 }

public class collisionDetect : MonoBehaviour
{
    public GameObject circle;
    public GameObject capsule;
    public GameObject topCircle;
    public GameObject botCircle;
    public GameObject square;
    public GameObject Mouse;

    
   

    Circle circ = new Circle();
    Capsule caps = new Capsule();
    Square squ = new Square();
    Circle mouse = new Circle();
    private void Start()
    {
        
    }
     void Update()
    {

        caps.position = capsule.transform.position;
        caps.radius = capsule.transform.localScale.x * 0.5f;
        caps.direction = capsule.transform.up;
        caps.halfHeight = capsule.transform.localScale.y * 0.5f;
        caps.top = caps.position + caps.direction * caps.halfHeight;
        caps.bot = caps.position - caps.direction * caps.halfHeight;

        circ.position = circle.transform.position;
        circ.radius = circle.transform.localScale.x * 0.5f;


        mouse.position = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouse.radius = circle.transform.localScale.x * .1f;
        Mouse.transform.position = mouse.position;

        squ.position = square.transform.position;
        squ.extents = new Vector3(square.transform.localScale.x * 0.5f, square.transform.localScale.y * 0.5f);
    
      Vector2 mtv = Vector2.zero;
        if (CheckCollisionCircleSquare(circ, squ)) 
        {
            circle.GetComponent<SpriteRenderer>().color = Color.green;
            square.GetComponent<SpriteRenderer>().color = Color.green;
        }
        else if (CheckCollisionCapsuleCircle(caps, circ, out mtv)) 
        {
            capsule.GetComponent<SpriteRenderer>().color = Color.green;
            circle.GetComponent<SpriteRenderer>().color = Color.green;
        }
        else if (CheckCollisionCapsuleSquare(caps, squ)) 
        {
            capsule.GetComponent<SpriteRenderer>().color = Color.green;
            square.GetComponent<SpriteRenderer>().color = Color.green;
        }
        else
        {
            capsule.GetComponent<SpriteRenderer>().color = Color.red;
            circle.GetComponent<SpriteRenderer>().color = Color.red;
            square.GetComponent<SpriteRenderer>().color = Color.red;
        }
    }
    bool CheckCollisionCircleSquare(Circle circ, Square squ)
    {
        Vector2 closestToCircle = circ.position;
        closestToCircle.x = Mathf.Clamp(closestToCircle.x, squ.position.x - squ.extents.x, squ.position.x + squ.extents.x);
        closestToCircle.y = Mathf.Clamp(closestToCircle.y, squ.position.y - squ.extents.y, squ.position.y + squ.extents.y);
       
        return Vector2.Distance(closestToCircle, circ.position) <= circ.radius;
    }

    
    bool CheckCollisionCapsuleCircle(Capsule capsule, Circle circle, out Vector2 mtv)
    {
       
        Vector2 AB = caps.bot - caps.top;
        Vector2 AC = circ.position - caps.top;
        float t = Vector2.Dot(AB, AC) / Vector2.Dot(AB, AB);
        t = Mathf.Clamp(t, 0.0f, 1.0f);
        Vector2 projection = caps.top + AB * t;

       
        float distance = Vector2.Distance(circ.position, projection);
        bool collision = distance <= circ.radius + caps.radius;
        mtv = collision ? (circ.position - projection).normalized * ((circ.radius + caps.radius) - distance) : Vector2.zero;
        return collision;
    }

    bool CheckCollisionCapsuleSquare(Capsule capsule, Square square)
    {
       
        Vector2 AB = caps.bot - caps.top;
        Vector2 AC = squ.position - caps.top;
        float t = Vector2.Dot(AB, AC) / Vector2.Dot(AB, AB);
        t = Mathf.Clamp(t, 0.0f, 1.0f);
        Vector2 projection = capsule.top + AB * t;

        Vector2 closestToCapsule = caps.position;
        closestToCapsule.x = Mathf.Clamp(closestToCapsule.x, squ.position.x - squ.extents.x, squ.position.x + squ.extents.x);
        closestToCapsule.y = Mathf.Clamp(closestToCapsule.y, squ.position.y - squ.extents.y, squ.position.y + squ.extents.y);

        return Vector2.Distance(closestToCapsule, projection) <= capsule.radius;
    }
}